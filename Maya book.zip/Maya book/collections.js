function shownavbar() {
    var navbar = document.querySelector(".side-navbar");
    
    if (navbar !== null) {
        // Toggle the display property between 'block' and 'none'
        navbar.style.left ="0"
    } else {
        console.error("Element with class 'navbar' not found.");
    }
}
function closenavbar(){
    var navbar = document.querySelector(".side-navbar");
    if (navbar !== null) {
        // Toggle the display property between 'block' and 'none'
        navbar.style.left =  "-60%"
    } 
    else {
        console.error("Element with class 'navbar' not found.");
    }
}
var productContainer = document.getElementById("product")
var searche =document.getElementById("search")
var productlist = productContainer.querySelectorAll("div")

searche.addEventListener("keyup",function(){
    var enteredValue=event.target.value.toUpperCase()

    for(count=0;count<productlist.length;count=count+1)
    {
        var productname=productlist[count].querySelector("p").textContent
        if(productname.toUpperCase().indexOf(enteredValue)<0)
        {
            productlist[count].style.display="none"
        }
        else{
            productlist[count].style.display="block"
        }

    }
})