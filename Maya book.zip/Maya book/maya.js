function shownavbar() {
    var navbar = document.querySelector(".side-navbar");
    
    if (navbar !== null) {
        // Toggle the display property between 'block' and 'none'
        navbar.style.left ="0"
    } else {
        console.error("Element with class 'navbar' not found.");
    }
}
function closenavbar(){
    var navbar = document.querySelector(".side-navbar");
    if (navbar !== null) {
        // Toggle the display property between 'block' and 'none'
        navbar.style.left =  "-60%"
    } 
    else {
        console.error("Element with class 'navbar' not found.");
    }
}