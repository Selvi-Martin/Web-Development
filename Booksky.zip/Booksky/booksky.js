var popoverlay =document.querySelector(".overlay")
var msg=document.querySelector(".boxmsg")
var addpopbtn=document.getElementById("add-popup-button")

function pop(){
    popoverlay.style.display="block"
    msg.style.display="block"
}
var can =document.getElementById("can-book")
can.addEventListener("click",function(event){
    event.preventDefault()
    popoverlay.style.display="none"
    msg.style.display="none"
})

//select container,add-book,id: title,author,des

var container=document.querySelector(".container")
var addbook=document.getElementById("add-book")
var booktitle=document.getElementById("title")
var bookauthor=document.getElementById("author")
var description=document.getElementById("des")
addbook.addEventListener("click",function(event){
    event.preventDefault()
    var div=document.createElement("div")
    div.setAttribute("class","book-container")
    div.innerHTML=`<h2>${booktitle.value}</h2>
    <h5>${bookauthor.value}</h5>
    <p>${description.value}</p>
    <button onclick="del(event)">Delete</button>`

    container.append(div)
    popoverlay.style.display="none"
    msg.style.display="none"
})

function del(event)
{
    event.target.parentElement.remove()     //parent container is used to delete the parent(i.e) book container of the button
}